//
//  _512App.swift
//  0512
//
//  Created by 張睿恩 on 2025/5/12.
//

import SwiftUI

@main
struct _512App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
