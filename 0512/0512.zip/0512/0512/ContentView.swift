//
//  ContentView.swift
//  0512
//
//  Created by 張睿恩 on 2025/5/12.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        AllPlantsView(plants: samplePlants)
    }
}

#Preview {
    ContentView()
}
