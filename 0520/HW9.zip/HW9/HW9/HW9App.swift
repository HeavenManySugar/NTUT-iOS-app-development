//
//  HW9App.swift
//  HW9
//
//  Created by 張睿恩 on 2025/5/20.
//

import SwiftUI

@main
struct HW9App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
