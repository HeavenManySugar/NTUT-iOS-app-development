//
//  HW7App.swift
//  HW7
//
//  Created by 張睿恩 on 2025/5/5.
//

import SwiftUI

@main
struct HW7App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
