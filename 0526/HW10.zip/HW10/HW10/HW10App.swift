//
//  HW10App.swift
//  HW10
//
//  Created by 張睿恩 on 2025/5/27.
//

import SwiftUI

@main
struct HW10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
