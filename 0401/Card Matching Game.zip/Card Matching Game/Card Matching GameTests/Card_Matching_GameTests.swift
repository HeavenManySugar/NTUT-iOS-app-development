//
//  Card_Matching_GameTests.swift
//  Card Matching GameTests
//
//  Created by 張睿恩 on 2025/3/4.
//

import Testing
@testable import Card_Matching_Game

struct Card_Matching_GameTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
